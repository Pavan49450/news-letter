import PDFTable from "../components/PDFTable";

const HomePage = () => {
  return <PDFTable />;
};

export default HomePage;
